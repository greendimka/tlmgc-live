import { Component, OnInit } from '@angular/core';
import { CustomersApiService } from './_services/customers-api.service';
import { Customer } from './_models/Customer';

@Component({
	moduleId: module.id,
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css']
})
export class AppComponent
	implements OnInit {


	requestInProgress = false;

	TabName = 'customer';

	CurrentCustomer: Customer = null;

	Customers: Customer[];


	constructor(private apiSvc: CustomersApiService) {
	}

	ngOnInit(): void {
		this.RequestData();
	}


	RequestData() {
		if (this.requestInProgress) { return; }

		this.requestInProgress = true;

		const scs = this.apiSvc.GetCustomers().subscribe(
			(value) => {
				console.log("Received data", value);
				this.CurrentCustomer = null;
				this.Customers = value;
			},
			(err) => { this.requestInProgress = false; },
			() => {
				this.requestInProgress = false;
				scs.unsubscribe();
			}
		);
	}


	SetCurrentCustomer(c: Customer) {
		this.CurrentCustomer = c;
	}


	SwitchTab(tabName: string) {
		switch (tabName) {
			case 'roles':
				this.TabName = 'roles';
				break;
			case 'permissions':
				this.TabName = 'permissions';
				break;
			default:
				this.TabName = 'customer';
				break;
		}
	}
}
