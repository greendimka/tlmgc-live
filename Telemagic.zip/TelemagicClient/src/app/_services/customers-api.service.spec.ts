/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { CustomersApiService } from './customers-api.service';

describe('Service: CustomersApi', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CustomersApiService]
    });
  });

  it('should ...', inject([CustomersApiService], (service: CustomersApiService) => {
    expect(service).toBeTruthy();
  }));
});