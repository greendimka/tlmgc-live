import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';

import { Customer } from '../_models/Customer';


//#region DTO classes

class CustomerDto {
	public address: string;

	public agentId: string;

	public city: string;

	public domain: string;

	public firstName: string;

	public lastName: string;

	public password: string;

	public permissions: object;

	public roles: string[] = [];

	public sipHost: string;

	public sipSecret: string;

	public sipUser: string;

	public username: string;


	public static ToModel(dto: CustomerDto): Customer {
		const rv = new Customer();

		if (dto.address) { rv.Address = dto.address; }
		if (dto.agentId) { rv.AgentId = dto.agentId; }
		if (dto.city) { rv.City = dto.city; }
		if (dto.domain) { rv.Domain = dto.domain; }
		if (dto.firstName) { rv.FirstName = dto.firstName; }
		if (dto.lastName) { rv.LastName = dto.lastName; }
		if (dto.password) { rv.Password = dto.password; }
		if (dto.sipHost) { rv.SipHost = dto.sipHost; }
		if (dto.sipSecret) { rv.SipSecret = dto.sipSecret; }
		if (dto.sipUser) { rv.SipUser = dto.sipUser; }
		if (dto.permissions) {
			for (const key in dto.permissions) {
				if (dto.permissions.hasOwnProperty(key)) {
					const val = dto.permissions[key];
					rv.Permissions.push({
						Key: key,
						Value: val
					});
				}
			}
		}
		if (dto.roles) {
			dto.roles.forEach(role => {
				if (role) {
					rv.Roles.push(role.trim());
				}
			});
		}

		// console.log("RV", rv);

		return rv;
	}
}

//#endregion


@Injectable()
export class CustomersApiService {

	private svcUrl = "/assets/data.json";

	constructor(private _http: Http) { }

	public GetCustomers(): Observable<Customer[]> {
		return this._http.get(this.svcUrl)
			.map(data => data.json())
			.map((customerDtos: CustomerDto[]) =>
				customerDtos.map(dto => CustomerDto.ToModel(dto)));
	}

}
