export class Customer {

	private _Address = "";
	public get Address(): string {
		return this._Address;
	}
	public set Address(v: string) {
		this._Address = this.s(v);
	}


	private _AgentId = "";
	public get AgentId(): string {
		return this._AgentId;
	}
	public set AgentId(v: string) {
		this._AgentId = this.s(v);
	}


	private _City = "";
	public get City(): string {
		return this._City;
	}
	public set City(v: string) {
		this._City = this.s(v);
	}


	private _Domain = "";
	public get Domain(): string {
		return this._Domain;
	}
	public set Domain(v: string) {
		this._Domain = this.s(v);
	}


	private _FirstName: string;
	public get FirstName(): string {
		return this._FirstName;
	}
	public set FirstName(v: string) {
		this._FirstName = this.s(v);
	}


	private _LastName: string;
	public get LastName(): string {
		return this._LastName;
	}
	public set LastName(v: string) {
		this._LastName = this.s(v);
	}


	private _Password: string;
	public get Password(): string {
		return this._Password;
	}
	public set Password(v: string) {
		this._Password = this.s(v);
	}


	private _SipHost: string;
	public get SipHost(): string {
		return this._SipHost;
	}
	public set SipHost(v: string) {
		this._SipHost = this.s(v);
	}


	private _SipSecret: string;
	public get SipSecret(): string {
		return this._SipSecret;
	}
	public set SipSecret(v: string) {
		this._SipSecret = this.s(v);
	}


	private _SipUser: string;
	public get SipUser(): string {
		return this._SipUser;
	}
	public set SipUser(v: string) {
		this._SipUser = this.s(v);
	}


	private _Username: string;
	public get Username(): string {
		return this._Username;
	}
	public set Username(v: string) {
		this._Username = this.s(v);
	}


	private _Roles: string[] = [];
	public get Roles(): string[] {
		return this._Roles;
	}



	private _Permissions: { Key: string, Value: boolean }[] = [];
	public get Permissions(): { Key: string, Value: boolean }[] {
		return this._Permissions;
	}



	private s(v: string) {
		if (v) {
			return v.trim();
		} else {
			return "";
		}
	}

}
