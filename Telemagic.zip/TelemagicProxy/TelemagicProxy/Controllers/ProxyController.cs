﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace TelemagicProxy.Controllers
{
	[Produces("application/json")]
	[Route("api/proxy")]
	public class ProxyController : Controller
	{
		private string creds = "assignment:fork823Spoon7Knife";
		private string svcUrl = "https://tmgdemo3.telemagic.no:8894/rest/agent";


		// GET: api/proxy
		[HttpGet]
		public async Task<IActionResult> Get()
		{
			var client = new HttpClient();


			// setting up accept and auth headers
			client.DefaultRequestHeaders.Accept.Clear();
			client.DefaultRequestHeaders.Accept.Add(
				new MediaTypeWithQualityHeaderValue("application/json"));

			client.DefaultRequestHeaders.Authorization
				= new AuthenticationHeaderValue("Basic",
				Convert.ToBase64String(Encoding.UTF8.GetBytes(creds)));


			HttpResponseMessage response = await client.GetAsync(svcUrl);
			HttpContent content = response.Content;

			if (response.IsSuccessStatusCode)
			{
				// simply forward - we are in a proxy
				return Ok(await content.ReadAsStreamAsync());
			}
			else
			{
				return await Task.FromResult(NotFound("Remote REST is unavailable."));
			}
		}


	}
}
